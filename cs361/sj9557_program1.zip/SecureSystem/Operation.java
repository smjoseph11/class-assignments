public enum Operation{
		READ,
		WRITE,
		BAD,
		EOF
}
